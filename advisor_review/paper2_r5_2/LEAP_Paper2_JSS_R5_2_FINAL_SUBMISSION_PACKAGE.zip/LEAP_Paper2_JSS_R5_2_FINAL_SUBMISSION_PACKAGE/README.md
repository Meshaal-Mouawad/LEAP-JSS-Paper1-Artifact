# LEAP Paper 2 — JSS FINAL Submission Package

This is the R5.2 editorial-closure package prepared after the final independent closure review.

Upload only the five files under `UPLOAD/`.

The only change from R5.1 is the page-7 terminology correction:
`30 labeled checker controls` → `30 binary checker controls`.

All scientific results and the supplementary evidence are unchanged.
